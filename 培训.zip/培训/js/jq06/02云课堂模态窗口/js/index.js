

$(document).ready(function(){
            ;(function(){

                 $('.login-l').click(function(){

                 $('.dark').fadeTo(400,0.4)
                 $('.login_win').fadeIn(400)
            })
            $('.login_win span').click(function(){
                $('.login_win,.dark').fadeOut(400)
            })
            })();

        ;(function(){
             var now = 'hide';
            $('.ask span').click(function(){
                if( now == 'hide'){
                    $(this).parent().animate({'right':0}, 300)
                    $(this).css('background','url(images/img/qqLOpen.jpg)')
                    now = 'show';
                }else{
                    $(this).parent().animate({'right':-131}, 300)
                    $(this).css('background','url(images/img/qqL.jpg)')
                    now = 'hide';

                }
                

            })

        })();
    
});